import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: "AIzaSyClSnebvF4z7bs0SPm7HGm_MaqVfvVetAQ",
  authDomain: "stockwizardlast.firebaseapp.com",
  projectId: "stockwizardlast",
  storageBucket: "stockwizardlast.firebasestorage.app",
  messagingSenderId: "699105853763",
  appId: "1:699105853763:web:1b48746ea0deda631a6ff6",
  measurementId: "G-Q4X5ZEMSNJ"
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);