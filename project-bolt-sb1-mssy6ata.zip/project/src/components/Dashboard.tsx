import React, { useState, useRef } from 'react';
import { User } from 'firebase/auth';
import { Upload, Image as ImageIcon } from 'lucide-react';
import * as tf from '@tensorflow/tfjs';
import '@tensorflow/tfjs-backend-webgl';
import * as cocoSsd from '@tensorflow-models/coco-ssd';
import { storage, db } from '../lib/firebase';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import toast from 'react-hot-toast';

interface Props {
  user: User;
}

export default function Dashboard({ user }: Props) {
  const [image, setImage] = useState<string | null>(null);
  const [predictions, setPredictions] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [modelLoading, setModelLoading] = useState(true);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [model, setModel] = useState<cocoSsd.ObjectDetection | null>(null);
  const [loadingProgress, setLoadingProgress] = useState(0);

  const loadModel = async () => {
    try {
      setModelLoading(true);
      setLoadingProgress(10);

      // Configure TensorFlow.js for optimal performance
      await tf.ready();
      setLoadingProgress(20);

      // Enable WebGL for faster processing
      await tf.setBackend('webgl');
      setLoadingProgress(40);

      // Configure memory management
      tf.engine().startScope();
      tf.env().set('WEBGL_FORCE_F16_TEXTURES', true);
      tf.env().set('WEBGL_VERSION', 2);
      tf.env().set('WEBGL_DELETE_TEXTURE_THRESHOLD', 0);
      setLoadingProgress(60);

      // Load the lightweight model
      const loadedModel = await cocoSsd.load({
        base: 'lite_mobilenet_v2',
        modelUrl: 'https://storage.googleapis.com/tfjs-models/savedmodel/lite_mobilenet_v2/model.json'
      });
      setLoadingProgress(90);

      setModel(loadedModel);
      tf.engine().endScope();
      toast.success('AI model loaded successfully');
      setLoadingProgress(100);
    } catch (error) {
      console.error('Error loading model:', error);
      toast.error('Error loading AI model. Please refresh the page.');
    } finally {
      setModelLoading(false);
    }
  };

  React.useEffect(() => {
    loadModel();
    return () => {
      // Cleanup TensorFlow memory
      tf.engine().disposeVariables();
    };
  }, []);

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setLoading(true);
    try {
      // Create image URL for display
      const imageUrl = URL.createObjectURL(file);
      setImage(imageUrl);

      // Upload to Firebase Storage
      const storageRef = ref(storage, `uploads/${user.uid}/${file.name}`);
      await uploadBytes(storageRef, file);
      const downloadUrl = await getDownloadURL(storageRef);

      // Process with TensorFlow.js
      if (model) {
        const img = new Image();
        img.src = imageUrl;
        await new Promise((resolve) => (img.onload = resolve));
        
        // Start a new scope for memory management
        tf.engine().startScope();
        const predictions = await model.detect(img);
        tf.engine().endScope();
        
        setPredictions(predictions);

        // Save to Firestore
        await addDoc(collection(db, 'predictions'), {
          userId: user.uid,
          imageUrl: downloadUrl,
          predictions,
          timestamp: serverTimestamp(),
        });

        toast.success('Image analyzed successfully!');
      }
    } catch (error) {
      console.error('Error processing image:', error);
      toast.error('Error processing image');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">Image Analysis</h2>
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-dark transition-colors"
            disabled={loading || modelLoading}
          >
            <Upload className="h-5 w-5 mr-2" />
            Upload Image
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleImageUpload}
            className="hidden"
          />
        </div>

        {modelLoading && (
          <div className="flex flex-col items-center justify-center p-12">
            <div className="w-64 h-3 bg-gray-200 rounded-full overflow-hidden mb-4">
              <div 
                className="h-full bg-primary transition-all duration-300 rounded-full"
                style={{ width: `${loadingProgress}%` }}
              ></div>
            </div>
            <p className="text-gray-600 dark:text-gray-400">
              Loading AI model... {loadingProgress}%
            </p>
            <p className="text-sm text-gray-500 mt-2">
              This may take a few moments on first load
            </p>
          </div>
        )}

        {loading && !modelLoading && (
          <div className="flex items-center justify-center p-12">
            <div className="animate-spin rounded-full h-12 w-12 border-4 border-primary border-t-transparent"></div>
          </div>
        )}

        {image && !loading && !modelLoading && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="relative">
              <img src={image} alt="Uploaded" className="w-full rounded-lg" />
            </div>
            <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
              <h3 className="text-xl font-semibold mb-4">Detected Objects</h3>
              <div className="space-y-2">
                {predictions.map((prediction, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between bg-white dark:bg-gray-800 p-3 rounded-lg"
                  >
                    <span className="font-medium">{prediction.class}</span>
                    <span className="text-sm text-gray-500">
                      {(prediction.score * 100).toFixed(1)}% confidence
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {!image && !loading && !modelLoading && (
          <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-12 text-center">
            <ImageIcon className="mx-auto h-12 w-12 text-gray-400" />
            <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
              Upload an image to start analyzing
            </p>
          </div>
        )}
      </div>
    </div>
  );
}